import 'still_glass.dart';
import 'look.dart';
import 'diag.dart';

import 'package:material_ui/material_ui.dart';

import '../core/theme.dart';
import '../widgets/pressable.dart';

/// The heading at the top of each of Prism's pages, with room for one glass button.
class PageTitle extends StatelessWidget {
  const PageTitle(this.title, {super.key, this.kicker, this.icon, this.onIcon});
  final String title;
  final String? kicker;
  final IconData? icon;
  final VoidCallback? onIcon;

  @override
  Widget build(BuildContext context) {
    final LumenColors c = LumenColors.of(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (kicker != null)
                Text(
                  kicker!.toUpperCase(),
                  style: LumenType.label(color: c.inkMuted),
                ),
              Text(
                title,
                style: LumenType.display(
                  40,
                  weight: 720,
                  color: c.ink,
                  height: 1.05,
                ),
              ),
            ],
          ),
        ),
        if (icon != null) GlassDot(icon: icon!, onTap: onIcon),
      ],
    );
  }
}

/// A round button: the small control at the top of a page.
class GlassDot extends StatelessWidget {
  const GlassDot({super.key, required this.icon, this.onTap});
  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final LumenColors c = LumenColors.of(context);
    return Pressable(
      onTap: onTap,
      child: SizedBox.square(
        dimension: 50,
        // Solid. As glass it scrolled with the page, so its backdrop changed every frame; Home was the slowest screen for it.
        child: DecoratedBox(
          decoration: ShapeDecoration(
            color: c.surfaceHigh,
            shape: CircleBorder(side: BorderSide(color: c.hairline)),
          ),
          child: Icon(icon, size: 22, color: c.ink),
        ),
      ),
    );
  }
}

/// The surface content sits on: a pane of still glass. The background behind it comes
/// through softened, under enough of the surface colour for text to read on. If there is no
/// background (lights off), it is the plain surface.
Decoration card(LumenColors c, {double radius = 28, Color? tint}) =>
    PaneDecoration(
      radius: radius,
      tint: tint ?? c.surface.withValues(alpha: c.dark ? 0.58 : 0.66),
      rim: Colors.white.withValues(alpha: c.dark ? 0.20 : 0.85),
      flat: c.surface,
      stamp: Diag.instance.wallpaperOn.value
          ? Look.instance.frostReady.value
          : -1,
    );
