package dev.lumen.lumen

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import io.flutter.plugin.common.MethodChannel
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestHighestRefreshRate()
    }

    private var device: MethodChannel? = null

    // Coming back from another app. Android throws away the surface an app draws on once the app
    // is out of sight, and until the app has drawn a new frame the window shows its plain
    // background: a dark, empty screen for a moment under the app that is shrinking away.
    // So just before leaving, the last frame is copied and made the window's background.
    // On return that picture is what shows until the first real frame replaces it.
    private var lastFrame: android.graphics.Bitmap? = null

    private fun surfaceIn(v: android.view.View): android.view.SurfaceView? {
        if (v is android.view.SurfaceView) return v
        if (v is android.view.ViewGroup) {
            for (i in 0 until v.childCount) {
                val found = surfaceIn(v.getChildAt(i))
                if (found != null) return found
            }
        }
        return null
    }

    // Prism has left the screen: if a rest is running, its countdown floats over whatever comes next.
    override fun onStop() {
        super.onStop()
        RestBubble.foreground = false
        RestBubble.refresh(applicationContext)
    }

    override fun onStart() {
        super.onStart()
        RestBubble.foreground = true
        RestBubble.awayInApp = false
        RestBubble.refresh(applicationContext)
    }

    override fun onPause() {
        try {
            val surface = surfaceIn(window.decorView)
            if (surface != null && surface.width > 0 && surface.height > 0 && surface.holder.surface.isValid) {
                var bmp = lastFrame
                if (bmp == null || bmp.width != surface.width || bmp.height != surface.height) {
                    bmp = android.graphics.Bitmap.createBitmap(surface.width, surface.height, android.graphics.Bitmap.Config.ARGB_8888)
                    lastFrame = bmp
                }
                val target = bmp!!
                android.view.PixelCopy.request(surface, target, { result ->
                    if (result == android.view.PixelCopy.SUCCESS) {
                        window.setBackgroundDrawable(android.graphics.drawable.BitmapDrawable(resources, target))
                    }
                }, android.os.Handler(android.os.Looper.getMainLooper()))
            }
        } catch (e: Exception) {
            // Without the picture, returning simply looks as it did before.
        }
        super.onPause()
    }

    // The home button was pressed while Prism is the home screen: tell the app, so it can go back to its first page.
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        if (intent.action == RestBubble.OPEN_TRAIN) {
            device?.invokeMethod("train", null)
        } else if (intent.action == RestBubble.OPEN_ACTION) {
            device?.invokeMethod("action", intent.getIntExtra("index", 0))
        } else if (intent.hasCategory(android.content.Intent.CATEGORY_HOME)) {
            device?.invokeMethod("home", null)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // Direct access to the vibration motor, for haptics that must be felt
        // even without a finger on the screen (the disco beat).
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "lumen/haptics").setMethodCallHandler { call, result ->
            if (call.method == "play") {
                play(call.arguments as? String ?: "tick")
                result.success(null)
            } else {
                result.notImplemented()
            }
        }
        // The apps installed on this phone, for the launcher experiments: names, icons, and opening one.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "lumen/apps").setMethodCallHandler { call, result ->
            when (call.method) {
                "list" -> Thread {
                    try {
                        val pm = packageManager
                        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER)
                        val out = ArrayList<Map<String, Any>>()
                        for (r in pm.queryIntentActivities(intent, 0)) {
                            val d = r.loadIcon(pm)
                            val bmp = android.graphics.Bitmap.createBitmap(144, 144, android.graphics.Bitmap.Config.ARGB_8888)
                            val c = android.graphics.Canvas(bmp)
                            d.setBounds(0, 0, 144, 144)
                            d.draw(c)
                            val bytes = java.io.ByteArrayOutputStream()
                            bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bytes)
                            out.add(mapOf("label" to r.loadLabel(pm).toString(), "package" to r.activityInfo.packageName, "icon" to bytes.toByteArray()))
                        }
                        runOnUiThread { result.success(out) }
                    } catch (e: Exception) {
                        runOnUiThread { result.error("apps", e.message, null) }
                    }
                }.start()
                "names" -> Thread {
                    // Every app on the home screen: its name, package and when it last changed. No pictures, so it is quick.
                    val out = ArrayList<Map<String, Any>>()
                    try {
                        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER)
                        for (r in packageManager.queryIntentActivities(intent, 0)) {
                            val pkg = r.activityInfo.packageName
                            val updated = try { packageManager.getPackageInfo(pkg, 0).lastUpdateTime } catch (e: Exception) { 0L }
                            out.add(mapOf("label" to r.loadLabel(packageManager).toString(), "package" to pkg, "updated" to updated))
                        }
                    } catch (e: Exception) {
                        // Leave the list as far as it got.
                    }
                    runOnUiThread { result.success(out) }
                }.start()
                "icons" -> Thread {
                    // The icon of each named app, and its one-colour outline where the app supplies one.
                    val out = ArrayList<Map<String, Any>>()
                    fun png(draw: (android.graphics.Canvas) -> Unit): ByteArray {
                        val bmp = android.graphics.Bitmap.createBitmap(96, 96, android.graphics.Bitmap.Config.ARGB_8888)
                        draw(android.graphics.Canvas(bmp))
                        val bytes = java.io.ByteArrayOutputStream()
                        bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bytes)
                        return bytes.toByteArray()
                    }
                    for (name in call.arguments as List<*>) {
                        try {
                            // A name starting with "label:" is looked up by what the app is called on the home screen.
                            var pkg = name as String
                            if (pkg.startsWith("label:")) {
                                val want = pkg.substring(6)
                                val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER)
                                pkg = packageManager.queryIntentActivities(intent, 0).first { it.loadLabel(packageManager).toString().equals(want, ignoreCase = true) }.activityInfo.packageName
                            }
                            val d = packageManager.getApplicationIcon(pkg)
                            val m = HashMap<String, Any>()
                            m["asked"] = name
                            m["package"] = pkg
                            m["icon"] = png { c -> d.setBounds(0, 0, 96, 96); d.draw(c) }
                            if (Build.VERSION.SDK_INT >= 33 && d is android.graphics.drawable.AdaptiveIconDrawable) {
                                val mono = d.monochrome
                                if (mono != null) {
                                    // An icon layer is drawn larger than what shows: only its middle two thirds is the picture.
                                    m["mono"] = png { c -> mono.mutate(); mono.setTint(android.graphics.Color.WHITE); mono.setBounds(-36, -36, 132, 132); mono.draw(c) }
                                }
                            }
                            out.add(m)
                        } catch (e: Exception) {
                            // Not installed.
                        }
                    }
                    runOnUiThread { result.success(out) }
                }.start()
                "launch" -> {
                    // Either just a package name, or a package with the place on screen it was opened from.
                    val a = call.arguments
                    val pkg = if (a is Map<*, *>) a["package"] as String else a as String
                    val i = packageManager.getLaunchIntentForPackage(pkg)
                    if (i != null) {
                        // What a home screen is expected to send: bring the app's existing task forward as it was left.
                        i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                        var opts: Bundle? = null
                        if (a is Map<*, *> && a["w"] != null) {
                            val x = (a["x"] as Number).toInt(); val y = (a["y"] as Number).toInt()
                            val w = (a["w"] as Number).toInt(); val h = (a["h"] as Number).toInt()
                            // The app opens out of the thing that was tapped, and Android is told where that was.
                            i.sourceBounds = android.graphics.Rect(x, y, x + w, y + h)
                            opts = android.app.ActivityOptions.makeClipRevealAnimation(window.decorView, x, y, w, h).toBundle()
                        }
                        startActivity(i, opts)
                    }
                    result.success(i != null)
                }
                else -> result.notImplemented()
            }
        }
        // Which phone this is, for the test report.
        device = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "lumen/device")
        RestBubble.channel = device
        device!!.setMethodCallHandler { call, result ->
            if (call.method == "rest") {
                // Everything the floating workout needs to know, or nothing if no workout is on.
                val a = call.arguments as? Map<*, *>
                if (a == null) {
                    RestBubble.active = false
                } else {
                    RestBubble.active = true
                    RestBubble.title = a["title"] as String
                    RestBubble.exercise = a["exercise"] as String
                    RestBubble.setLabel = a["set"] as String
                    RestBubble.current = (a["current"] as Number).toInt()
                    RestBubble.sets = (a["sets"] as List<*>).map {
                        val m = it as Map<*, *>
                        RestBubble.SetRow((m["kg"] as Number).toDouble(), (m["reps"] as Number).toInt(), m["done"] as Boolean)
                    }
                    RestBubble.endsAt = (a["endsAt"] as Number).toLong()
                    RestBubble.total = (a["total"] as Number).toInt()
                    RestBubble.sinceAt = (a["sinceAt"] as Number).toLong()
                    RestBubble.countUp = a["countUp"] as Boolean
                    RestBubble.hapticsOn = a["haptics"] as Boolean
                    RestBubble.accent = (a["accent"] as Number).toInt()
                    RestBubble.onAccent = (a["onAccent"] as Number).toInt()
                }
                RestBubble.refresh(applicationContext)
                result.success(null)
            } else if (call.method == "pin") {
                // What is pinned from the blob menu to float over the phone, or nothing.
                val a = call.arguments as? Map<*, *>
                if (a == null) {
                    RestBubble.pin = null
                } else {
                    val bytes = a["icon"] as? ByteArray
                    val bmp = if (bytes != null) android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) else null
                    RestBubble.pin = RestBubble.Pin(
                        a["key"] as String, a["kind"] as String, (a["index"] as Number).toInt(), a["package"] as String,
                        a["name"] as String, (a["color"] as Number).toInt(), bmp, a["picture"] as Boolean,
                    )
                }
                RestBubble.refresh(applicationContext)
                result.success(null)
            } else if (call.method == "pinData") {
                // The numbers the pinned sheets show.
                val a = call.arguments as Map<*, *>
                RestBubble.light = a["light"] as Boolean
                RestBubble.hapticsOn = a["haptics"] as Boolean
                RestBubble.accent = (a["accent"] as Number).toInt()
                RestBubble.onAccent = (a["onAccent"] as Number).toInt()
                RestBubble.weight = (a["weight"] as Number).toDouble()
                RestBubble.kcalLeft = (a["left"] as Number).toInt()
                RestBubble.meals = (a["meals"] as List<*>).map {
                    val m = it as Map<*, *>
                    RestBubble.Meal((m["i"] as Number).toInt(), m["name"] as String, m["what"] as String, (m["kcal"] as Number).toInt())
                }
                RestBubble.refresh(applicationContext)
                result.success(null)
            } else if (call.method == "page") {
                // Whether Prism's own workout page is the one showing.
                RestBubble.page(applicationContext, call.arguments as Boolean)
                result.success(null)
            } else if (call.method == "overlayAllowed") {
                result.success(android.provider.Settings.canDrawOverlays(this))
            } else if (call.method == "usageAllowed") {
                result.success(RestBubble.usageAllowed(this))
            } else if (call.method == "askUsage") {
                try {
                    startActivity(android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS, android.net.Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    try { startActivity(android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (e2: Exception) {}
                }
                result.success(null)
            } else if (call.method == "askOverlay") {
                try {
                    startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                }
                result.success(null)
            } else if (call.method == "battery") {
                // One reading of the battery: how full, how fast it is draining, whether it is charging.
                val bm = getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
                val sticky = registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
                val bright = try { android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 0 }
                result.success(mapOf(
                    "level" to bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY),
                    "current" to bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CURRENT_NOW),
                    "counter" to bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER),
                    "plugged" to ((sticky?.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0),
                    "temp" to (sticky?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0),
                    "brightness" to bright,
                ))
            } else if (call.method == "power") {
                // Battery level, heat and power saving: they change how fast the phone is willing to draw.
                val bm = getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
                val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                val heat = arrayOf("cool", "light", "moderate", "severe", "critical", "emergency", "shutdown").getOrElse(pm.currentThermalStatus) { "?" }
                result.success("battery ${bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)}%, heat $heat, power saving ${if (pm.isPowerSaveMode) "ON" else "off"}")
            } else if (call.method == "info") {
                result.success("${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.SOC_MODEL}")
            } else {
                result.notImplemented()
            }
        }
        // Streams the direction of gravity, so cards can tilt with the phone.
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "lumen/tilt").setStreamHandler(
            object : EventChannel.StreamHandler {
                private var listener: SensorEventListener? = null
                private val sensors = getSystemService(Context.SENSOR_SERVICE) as SensorManager

                override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                    val sensor = sensors.getDefaultSensor(Sensor.TYPE_GRAVITY)
                        ?: sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                    if (sensor == null) {
                        events.error("no_sensor", "No gravity sensor", null)
                        return
                    }
                    val l = object : SensorEventListener {
                        override fun onSensorChanged(e: SensorEvent) {
                            events.success(doubleArrayOf(
                                e.values[0].toDouble() / SensorManager.GRAVITY_EARTH,
                                e.values[1].toDouble() / SensorManager.GRAVITY_EARTH,
                                e.values[2].toDouble() / SensorManager.GRAVITY_EARTH,
                            ))
                        }
                        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
                    }
                    listener = l
                    sensors.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
                }

                override fun onCancel(arguments: Any?) {
                    listener?.let { sensors.unregisterListener(it) }
                    listener = null
                }
            }
        )
    }

    private val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    // tick: a notch or selection. click: something settled. thud: a beat,
    // an end stop or a refusal.
    private fun play(kind: String) {
        if (!vibrator.hasVibrator()) return
        val (primitive, scale, predefined, fallbackMs) = when (kind) {
            "thud" -> Quad(VibrationEffect.Composition.PRIMITIVE_THUD, 1.0f, VibrationEffect.EFFECT_HEAVY_CLICK, 28L)
            "click" -> Quad(VibrationEffect.Composition.PRIMITIVE_CLICK, 0.7f, VibrationEffect.EFFECT_CLICK, 14L)
            else -> Quad(VibrationEffect.Composition.PRIMITIVE_TICK, 1.0f, VibrationEffect.EFFECT_TICK, 8L)
        }
        val effect: VibrationEffect = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && vibrator.areAllPrimitivesSupported(primitive) ->
                VibrationEffect.startComposition().addPrimitive(primitive, scale).compose()
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> VibrationEffect.createPredefined(predefined)
            else -> VibrationEffect.createOneShot(fallbackMs, 255)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Media usage, so the phone's silent mode and touch-feedback
            // setting do not mute the demo. The app has its own Haptics switch.
            vibrator.vibrate(effect, VibrationAttributes.createForUsage(VibrationAttributes.USAGE_MEDIA))
        } else {
            vibrator.vibrate(effect)
        }
    }

    private data class Quad(val primitive: Int, val scale: Float, val predefined: Int, val ms: Long)

    // Ask for the fastest display mode at the current resolution, so the app
    // runs at 120 Hz where the phone would otherwise default it to 60.
    private fun requestHighestRefreshRate() {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay
        } ?: return
        val current = display.mode
        val best = display.supportedModes
            .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
            .maxByOrNull { it.refreshRate } ?: return
        val params = window.attributes
        params.preferredDisplayModeId = best.modeId
        window.attributes = params
    }
}

/**
 * The workout, floating over the whole phone.
 *
 * While a workout is on, a small glass lens floats over whatever is on screen: other apps,
 * the app switcher, and every page of Prism. It is in the same place everywhere and behaves
 * the same everywhere. It has three sizes on one axis:
 *
 *   lens    a glance: the timer. Drag it anywhere; drop it on the cross at the bottom to close it.
 *   compact a bottom sheet in the thumb's reach: the current set on two dials, and "Set done".
 *   full    the same sheet grown tall: a large timer, every set of the exercise, rest controls.
 *
 * Tap the lens for the sheet. Swipe the sheet up to grow it, down to shrink it, down again
 * to fold it back into the lens. Everything is drawn by Android itself, and nothing exists
 * when no workout is on.
 */
object RestBubble {
    const val OPEN_TRAIN = "dev.lumen.OPEN_TRAIN"

    class SetRow(var kg: Double, var reps: Int, var done: Boolean)

    var channel: MethodChannel? = null
    var active = false
    var title = ""
    var exercise = ""
    var setLabel = ""
    var sets: List<SetRow> = emptyList()
    var current = 0
    var endsAt = 0L
    var total = 90
    var sinceAt = 0L
    var countUp = false
    var accent = 0xFFFFAE1A.toInt()
    var onAccent = 0xFF1D1300.toInt()
    var foreground = true
    var onTrain = false

    /** Prism's own Haptics switch. The floating parts obey it too. */
    var hapticsOn = true

    /** Something from Prism's blob menu, pinned to float over the phone. */
    class Pin(val key: String, val kind: String, val index: Int, val pkg: String, val name: String, val color: Int, val icon: android.graphics.Bitmap?, val picture: Boolean)

    class Meal(val index: Int, val name: String, val what: String, val kcal: Int)

    const val OPEN_ACTION = "dev.lumen.OPEN_ACTION"
    var pin: Pin? = null
    var weight = 80.0
    var kcalLeft = 0
    var meals: List<Meal> = emptyList()

    /** After the lens has opened an app it keeps out of the way until Prism is next on screen. */
    var awayInApp = false

    private var view: Dot? = null
    private var target: Target? = null
    private var sheet: Sheet? = null

    /**
     * While a sheet is open the lens sits on the sheet's top corner, as the button that folds
     * it away again. It goes back to where it was when the sheet closes.
     */
    private var docked = false
    private var homeX = 0
    private var homeY = 0
    private var dockX = -1
    private var dockY = -1
    private var lensOffX = 0
    private var lensOffY = 0
    private var dismissed = false
    private var fullMode = false
    private var lensX = -1
    private var lensY = -1
    // How large the lens is, in pixels. Nothing until it is first shown; then its usual size, or the
    // size two fingers last gave it.
    private var lensSize = 0
    private var reach: Reach? = null
    // Tucked into a side of the screen, and which side.
    private var tucked = false
    private var tuckRight = true

    /** Prism's theme. The sheets follow it. The lens is always dark glass, so it reads over any app. */
    var light = false

    private fun ink(): Int = if (light) 0xFF17150F.toInt() else WHITE

    private fun muted(): Int = if (light) 0xFF5E5A50.toInt() else GREY

    private const val WHITE = 0xFFFFFFFF.toInt()
    private const val GREY = 0xFFA9ACB6.toInt()
    private const val GREEN = 0xFF2FA84F.toInt()

    private fun wm(context: Context) = context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager

    fun clock(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    fun number(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else String.format(java.util.Locale.US, "%.1f", v)

    private fun tint(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

    private fun shade(color: Int, value: Float, alpha: Int): Int {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(color, hsv)
        hsv[2] = (hsv[2] * value).coerceIn(0f, 1f)
        return android.graphics.Color.HSVToColor(alpha, hsv)
    }

    /** The same three clicks Prism's own dials make. */
    fun haptic(context: Context, kind: String) {
        if (!hapticsOn) return
        try {
            val vib: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (!vib.hasVibrator()) return
            val primitive = when (kind) {
                "thud" -> VibrationEffect.Composition.PRIMITIVE_THUD
                "click" -> VibrationEffect.Composition.PRIMITIVE_CLICK
                else -> VibrationEffect.Composition.PRIMITIVE_TICK
            }
            val effect: VibrationEffect = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && vib.areAllPrimitivesSupported(primitive) ->
                    VibrationEffect.startComposition().addPrimitive(primitive, if (kind == "click") 0.7f else 1f).compose()
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> VibrationEffect.createPredefined(
                    when (kind) {
                        "thud" -> VibrationEffect.EFFECT_HEAVY_CLICK
                        "click" -> VibrationEffect.EFFECT_CLICK
                        else -> VibrationEffect.EFFECT_TICK
                    },
                )
                else -> VibrationEffect.createOneShot(if (kind == "thud") 28L else 10L, 255)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                vib.vibrate(effect, VibrationAttributes.createForUsage(VibrationAttributes.USAGE_MEDIA))
            } else {
                vib.vibrate(effect)
            }
        } catch (e: Throwable) {
            // No vibration is not worth failing over.
        }
    }

    /**
     * Which lens is due. There is one place for a lens: a workout has it while it is on (1);
     * otherwise a pinned thing has it (2); otherwise there is none (0).
     */
    private fun mode(): Int = when {
        active -> if (!dismissed) 1 else 0
        pin != null && !awayInApp -> 2
        else -> 0
    }

    /** The colour the lens is tinted with. */
    private fun lensColor(): Int = if (active) accent else (pin?.color ?: accent)

    /**
     * Whether Android lets Prism see which app is in front. Used for one thing: a pinned app's
     * lens, which steps aside when it has opened its app, comes back the moment that app is left.
     */
    fun usageAllowed(context: Context): Boolean {
        return try {
            val ops = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName)
            } else {
                @Suppress("DEPRECATION")
                ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName)
            }
            mode == android.app.AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    private val watcher = android.os.Handler(android.os.Looper.getMainLooper())
    private var watching = false

    /**
     * The lens has opened its pinned app and stepped aside. Three times a second, and only until
     * that app is left, this looks at which app is in front; when it is another one (the list of
     * recent apps counts), the lens comes back. Nothing runs while the screen is off, and nothing
     * at all if Android has not been told Prism may look.
     */
    private fun watchAway(context: Context) {
        if (watching || !usageAllowed(context)) return
        val app = context.applicationContext
        watching = true
        val began = System.currentTimeMillis()
        var from = began - 3000
        var seen = false
        var gone = 0
        watcher.postDelayed(object : Runnable {
            override fun run() {
                val p = pin
                if (!awayInApp || p == null) {
                    watching = false
                    return
                }
                var next = 330L
                try {
                    val power = app.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                    if (!power.isInteractive) {
                        next = 3000L
                    } else {
                        val usage = app.getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
                        val now = System.currentTimeMillis()
                        val events = usage.queryEvents(from, now + 1000)
                        val e = android.app.usage.UsageEvents.Event()
                        var front: String? = null
                        while (events.hasNextEvent()) {
                            events.getNextEvent(e)
                            if (e.eventType == 1) { // an app's screen came to the front
                                front = e.packageName
                                from = e.timeStamp
                            }
                        }
                        if (front == p.pkg) {
                            seen = true
                            gone = 0
                        } else if (front != null && (seen || now - began > 2500)) {
                            // Seen twice running, so that one screen of the app handing over to another is not mistaken for leaving.
                            gone++
                        }
                        if (gone >= 2) {
                            watching = false
                            awayInApp = false
                            refresh(app)
                            return
                        }
                    }
                } catch (ex: Exception) {
                    watching = false
                    return
                }
                watcher.postDelayed(this, next)
            }
        }, 330)
    }

    /** A pinned thing's lens was tapped: it does what the thing is. */
    private fun tapPinned(context: Context) {
        val p = pin ?: return
        if (p.kind == "app") {
            val i = context.packageManager.getLaunchIntentForPackage(p.pkg)
            if (i != null) {
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                try { context.startActivity(i) } catch (e: Exception) {}
                // Out of the way while that app is in front. It is back when that app is left, if
                // Android lets Prism see that; otherwise when Prism is next on screen.
                awayInApp = true
                refresh(context)
                watchAway(context)
            } else {
                haptic(context, "thud")
            }
        } else if (p.index == 1 || p.index == 3) {
            // Logging food and weighing in are done right here, over whatever is open.
            openSheet(context)
        } else {
            // No floating version of this one yet: it opens in Prism.
            openAction(context, p.index)
        }
    }

    /** Opens Prism at one of its own actions. */
    private fun openAction(context: Context, index: Int) {
        closeSheet(context)
        val i = android.content.Intent(context, MainActivity::class.java)
            .setAction(OPEN_ACTION)
            .putExtra("index", index)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        try { context.startActivity(i) } catch (ex: Exception) {}
    }

    /** Something changed: decide whether the lens should be there, and bring what is shown up to date. */
    fun refresh(context: Context) {
        val want = mode() != 0 && android.provider.Settings.canDrawOverlays(context)
        if (!want) {
            remove(context)
            return
        }
        if (view == null) add(context)
        sheet?.sync()
        view?.invalidate()
    }

    /** Prism's workout page came on screen or left it. Going to it brings back a lens that was closed. */
    fun page(context: Context, train: Boolean) {
        onTrain = train
        if (train) dismissed = false
        refresh(context)
    }

    private fun add(context: Context) {
        try {
            val d = context.resources.displayMetrics
            val dp = d.density
            // The cross to drop it on. Added first, so it lies under the lens; it cannot be touched.
            val t = Target(context)
            val tlp = android.view.WindowManager.LayoutParams(
                (150 * dp).toInt(), (150 * dp).toInt(),
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT,
            )
            tlp.gravity = android.view.Gravity.TOP or android.view.Gravity.START
            tlp.x = d.widthPixels / 2 - (75 * dp).toInt()
            tlp.y = d.heightPixels - (104 * dp).toInt() - (75 * dp).toInt()
            t.alpha = 0f
            wm(context).addView(t, tlp)
            target = t

            val least = (84 * dp).toInt()
            val most = Math.max(least, minOf(d.widthPixels, d.heightPixels) - (16 * dp).toInt())
            if (lensSize == 0) {
                // The size it was last given, kept from one day to the next.
                val saved = try { context.getSharedPreferences("prism_lens", Context.MODE_PRIVATE).getFloat("size", 84f) } catch (e: Exception) { 84f }
                lensSize = (saved * dp).toInt()
            }
            lensSize = lensSize.coerceIn(least, most)
            val size = lensSize
            val lp = android.view.WindowManager.LayoutParams(
                size, size,
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT,
            )
            lp.gravity = android.view.Gravity.TOP or android.view.Gravity.START
            // It goes exactly where it is put: Android adds no slide of its own.
            if (Build.VERSION.SDK_INT >= 34) lp.setCanPlayMoveAnimation(false)
            // Where it was last left, so it is in the same spot everywhere.
            if (lensX < 0) tucked = false
            lp.x = if (lensX >= 0) lensX else d.widthPixels - size - (8 * dp).toInt()
            lp.y = if (lensY >= 0) lensY else (d.heightPixels * 0.30f).toInt()
            val v = Dot(context, lp)
            wm(context).addView(v, lp)
            view = v
        } catch (e: Exception) {
            view = null
        }
    }

    private fun remove(context: Context) {
        closeReach(context)
        removeSheet(context)
        val t = target
        target = null
        if (t != null) try { wm(context).removeView(t) } catch (e: Exception) {}
        val v = view ?: return
        view = null
        try { wm(context).removeView(v) } catch (e: Exception) {}
    }

    private fun openPrism(context: Context) {
        closeSheet(context)
        val i = android.content.Intent(context, MainActivity::class.java)
            .setAction(OPEN_TRAIN)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        try { context.startActivity(i) } catch (ex: Exception) {}
    }

    private fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeWidth: Int = 0): android.graphics.drawable.GradientDrawable {
        val g = android.graphics.drawable.GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius
        if (strokeWidth > 0) g.setStroke(strokeWidth, stroke)
        return g
    }

    private fun label(context: Context, size: Float, color: Int, bold: Boolean): android.widget.TextView {
        val t = android.widget.TextView(context)
        t.textSize = size
        t.setTextColor(color)
        t.typeface = android.graphics.Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", if (bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        t.includeFontPadding = false
        return t
    }

    private fun openSheet(context: Context) {
        if (sheet != null) return
        try {
            val d = context.resources.displayMetrics
            val dp = d.density
            val p = pin
            val host: Sheet = if (active || p == null) WorkoutSheet(context) else ActionSheet(context, p.index)
            val lp = android.view.WindowManager.LayoutParams(
                minOf(d.widthPixels - (16 * dp).toInt(), (440 * dp).toInt()), android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                // The third flag asks Android to treat the sheet as something a keyboard belongs above,
                // so that a keyboard is not covered by it.
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or android.view.WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    android.view.WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,
                android.graphics.PixelFormat.TRANSLUCENT,
            )
            // Always at the bottom, wherever the lens is: that is where a thumb reaches.
            lp.gravity = android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
            lp.y = (14 * dp).toInt()
            // When it changes size it is simply the new size: Android adds no slide of its own.
            if (Build.VERSION.SDK_INT >= 34) lp.setCanPlayMoveAnimation(false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // And to keep it clear of a keyboard: when one is up, the sheet sits on top of it.
                lp.fitInsetsTypes = android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.ime()
            }
            wm(context).addView(host, lp)
            sheet = host
            val v = view
            if (v != null) {
                // The lens stays, and moves to the sheet's corner. Where it is on the screen and
                // where its window was asked to be can differ by a fixed amount; measure it once.
                val at = IntArray(2)
                v.getLocationOnScreen(at)
                lensOffX = at[0] - v.lp.x
                lensOffY = at[1] - v.lp.y
                homeX = v.lp.x
                homeY = v.lp.y
                dockX = -1
                dockY = -1
                docked = true
            }
            host.arrive()
        } catch (e: Exception) {
            sheet = null
        }
    }

    /** Folds the sheet away. The lens sets off for its own place at the same moment. */
    private fun closeSheet(context: Context) {
        val s = sheet ?: return
        undock()
        s.leave { if (sheet === s) removeSheet(context) }
    }

    /** The lens leaves the sheet's corner and goes back to where it was. */
    private fun undock() {
        val v = view
        if (docked && v != null) {
            docked = false
            v.glideTo(homeX.toFloat(), homeY.toFloat(), 300, lensSize)
        }
        docked = false
    }

    private fun removeSheet(context: Context) {
        val s = sheet ?: return
        sheet = null
        try { wm(context).removeView(s) } catch (e: Exception) {}
        undock()
    }

    /**
     * Puts the lens on the open sheet's top right corner, just above it. Called again whenever
     * the sheet may have moved or changed size; [ms] is how long the lens takes to get there.
     */
    private fun dock(context: Context, ms: Long = 300) {
        val v = view ?: return
        val s = sheet ?: return
        if (!docked || s.width == 0) return
        val dp = context.resources.displayMetrics.density
        val at = IntArray(2)
        s.getLocationOnScreen(at)
        // On the corner it is always its usual size, however large it has been made.
        val small = (84 * dp).toInt()
        val x = at[0] + s.width - small - (2 * dp).toInt() - lensOffX
        val y = at[1] + s.glassTop() - small - (2 * dp).toInt() - lensOffY
        if (Math.abs(x - dockX) < 2 && Math.abs(y - dockY) < 2) return
        dockX = x
        dockY = y
        v.glideTo(x.toFloat(), y.toFloat(), ms, small)
    }

    /**
     * While a finger is on the lens, the rest of the screen listens for a second one, so that two
     * fingers can resize the lens wherever the second one lands. It is there only for as long as
     * the lens is being touched, and it shows nothing.
     */
    private class Reach(context: Context) : android.view.View(context) {
        override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
            val v = view ?: return true
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_MOVE -> v.second(true, e.rawX, e.rawY)
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> v.second(false, 0f, 0f)
            }
            return true
        }
    }

    private fun openReach(context: Context) {
        if (reach != null) return
        try {
            val r = Reach(context)
            val lp = android.view.WindowManager.LayoutParams(
                android.view.WindowManager.LayoutParams.MATCH_PARENT, android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or android.view.WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
                android.graphics.PixelFormat.TRANSLUCENT,
            )
            wm(context).addView(r, lp)
            reach = r
        } catch (e: Exception) {
            reach = null
        }
    }

    private fun closeReach(context: Context) {
        val r = reach ?: return
        reach = null
        try { wm(context).removeView(r) } catch (e: Exception) {}
    }

    // How everything here moves: quickly at first, then slowing into its place. Nothing goes
    // past its place and comes back.
    private val EASE = android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f)

    private fun smooth(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** What the timer shows, the same for the lens and for the sheet. */
    private class Reading(val text: String, val part: Float, val resting: Boolean, val go: Boolean, val urgent: Boolean, val what: String)

    private fun reading(now: Long): Reading {
        val left = endsAt - now
        val resting = left > 0
        val go = endsAt > 0 && !resting && now - endsAt < 3000
        val since = now - sinceAt
        if (go) return Reading("GO", 1f, false, true, false, "REST IS OVER")
        if (resting) {
            val gone = (total * 1000L - left).coerceAtLeast(0)
            return if (countUp) {
                Reading(clock(gone), (gone / (total * 1000f)).coerceIn(0f, 1f), true, false, left <= 10000, "RESTING")
            } else {
                Reading(clock(left + 999), (left / (total * 1000f)).coerceIn(0f, 1f), true, false, left <= 10000, "REST LEFT")
            }
        }
        return Reading(clock(since), -1f, false, false, false, "SINCE LAST SET")
    }

    /**
     * The cross at the bottom of the screen that a lens is dropped on to close it. When the
     * lens falls in, the cross takes its colour, swallows, jiggles the way the centre button
     * does when the drop lands on it, sends out one ring, and sinks out of sight.
     */
    private class Target(context: Context) : android.view.View(context) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val dp = resources.displayMetrics.density
        private val mix = android.animation.ArgbEvaluator()
        private var gulp = -1f
        private var taken = 0
        var held = false
            set(v) {
                if (field != v) {
                    field = v
                    animate().scaleX(if (v) 1.28f else 1f).scaleY(if (v) 1.28f else 1f).setDuration(160)
                        .setInterpolator(android.view.animation.OvershootInterpolator(2.5f)).start()
                    invalidate()
                }
            }

        fun swallow(color: Int, done: () -> Unit) {
            taken = color
            animate().cancel()
            val a = android.animation.ValueAnimator.ofFloat(0f, 1f)
            a.duration = 900
            a.interpolator = android.view.animation.LinearInterpolator()
            a.addUpdateListener {
                val t = it.animatedValue as Float
                gulp = t
                // It was swollen to hold the lens; it eases back to its own size as it swallows.
                val base = 1.28f - 0.28f * Math.min(1f, t / 0.45f)
                // Wider, taller, wider, dying away: a drop that has just landed.
                val w = 0.24f * Math.exp(-5.5 * t).toFloat() * Math.cos(2 * Math.PI * 3.4 * t).toFloat()
                scaleX = base * (1 + w)
                scaleY = base * (1 - w)
                // Then it sinks.
                val s = ((t - 0.6f) / 0.4f).coerceIn(0f, 1f)
                translationY = s * s * 150 * dp
                alpha = 1f - s
                invalidate()
            }
            a.addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    done()
                }
            })
            a.start()
        }

        override fun onDraw(canvas: android.graphics.Canvas) {
            val c = width / 2f
            val r = 40 * dp
            val dark = if (held) 0xE6181A20.toInt() else 0xCC101216.toInt()
            // While swallowing, the colour of what fell in shows through and then fades.
            val colour = if (gulp >= 0f) (Math.max(0f, 1f - gulp / 0.5f)) else 0f
            if (gulp >= 0f && gulp < 0.55f) {
                // One ring, going out.
                val k = gulp / 0.55f
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = 2.4f * dp * (1 - k)
                paint.color = tint(taken, ((1 - k) * 170).toInt().coerceIn(0, 255))
                canvas.drawCircle(c, c, r * (1f + 0.75f * k), paint)
            }
            paint.style = android.graphics.Paint.Style.FILL
            paint.color = if (colour > 0f) mix.evaluate(colour, dark, tint(taken, 0xF0)) as Int else dark
            canvas.drawCircle(c, c, r, paint)
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = (if (held) 2.2f else 1.4f) * dp
            paint.color = if (held || gulp >= 0f) accent else 0x66FFFFFF
            canvas.drawCircle(c, c, r - paint.strokeWidth / 2, paint)
            // The cross closes as it swallows.
            val a = 9 * dp * (if (gulp >= 0f) Math.max(0f, 1f - gulp / 0.25f) else 1f)
            if (a > 0.5f) {
                paint.strokeWidth = 2.6f * dp
                paint.strokeCap = android.graphics.Paint.Cap.ROUND
                paint.color = WHITE
                canvas.drawLine(c - a, c - a, c + a, c + a, paint)
                canvas.drawLine(c - a, c + a, c + a, c - a, paint)
            }
        }
    }

    /**
     * The lens: a see-through tinted disc (what is underneath shows through it), a rim lit from
     * above and a soft highlight across the top. During a workout it carries the timer. For a
     * pinned thing it carries that thing's picture and its colour, and nothing in it moves.
     */
    private class Dot(context: Context, val lp: android.view.WindowManager.LayoutParams) : android.view.View(context) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val arc = android.graphics.RectF()
        private val dst = android.graphics.RectF()
        private val clip = android.graphics.Path()
        private val round = android.graphics.Path()
        private var body: android.graphics.Shader? = null
        private var bodyDone: android.graphics.Shader? = null
        private var rim: android.graphics.Shader? = null
        private var shine: android.graphics.Shader? = null
        private var glow: android.graphics.Shader? = null
        private var shadow: android.graphics.Shader? = null
        private var shadersFor = 0
        private var shadersPinned = false
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
        private var dragged = false
        private var snapped = false
        private var buzzedFor = 0L
        private val dp = resources.displayMetrics.density
        private var tracker: android.view.VelocityTracker? = null
        // The springs that carry it to rest after a throw.
        private var px = 0f; private var py = 0f; private var vx = 0f; private var vy = 0f
        private var tx = 0f; private var ty = 0f
        private var springing = false
        private var lastFrame = 0L
        private var leaving = false
        private var glide: android.animation.ValueAnimator? = null
        // How far it is tucked into the side: 0 is out, 1 is away with only a sliver showing.
        private var tuck = if (tucked) 1f else 0f
        private var tucking: android.animation.ValueAnimator? = null
        private var wouldTuck = false
        // The rest of this touch is not for the lens.
        private var ignoring = false
        // The size everything in the lens is drawn for. It is then scaled to the size the lens is.
        private val base = 84 * dp
        // Two fingers resizing it: where each is on the screen, how far apart they began, and the
        // size the lens had then.
        private var pressed = false
        private var sizing = false
        private var sized = false
        private var stretching = false
        private var atEnd = false
        private var wantSize = 0f
        private var p1x = 0f; private var p1y = 0f; private var p2x = 0f; private var p2y = 0f
        private var startDist = 1f
        private var startSize = 0f
        private var midX = 0f; private var midY = 0f

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            scaleX = 0.8f; scaleY = 0.8f; alpha = 0f
            animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220).setInterpolator(EASE).start()
        }

        private fun shaders() {
            val c = lensColor()
            val pinned = !active
            val r = base / 2f
            val disc = r - 5 * dp
            // A workout's lens is nearly clear, with a breath of the colour. A pinned thing's lens is
            // filled with its own colour, like the blob it came from, but still lets the app show through.
            body = android.graphics.RadialGradient(
                r - disc * 0.35f, r - disc * 0.45f, disc * 1.7f,
                if (pinned) intArrayOf(shade(c, 1.06f, 0xD2), shade(c, 0.82f, 0xDC), shade(c, 0.5f, 0xEA))
                else intArrayOf(shade(c, 0.36f, 0x78), shade(c, 0.18f, 0xB4), 0xD60A0B0E.toInt()),
                floatArrayOf(0f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP,
            )
            bodyDone = android.graphics.RadialGradient(
                r - disc * 0.35f, r - disc * 0.45f, disc * 1.7f,
                intArrayOf(shade(c, 1.18f, 0xFF), c, shade(c, 0.72f, 0xFF)),
                floatArrayOf(0f, 0.5f, 1f), android.graphics.Shader.TileMode.CLAMP,
            )
            rim = android.graphics.LinearGradient(0f, r - disc, 0f, r + disc, 0xB8FFFFFF.toInt(), 0x14FFFFFF, android.graphics.Shader.TileMode.CLAMP)
            shine = android.graphics.LinearGradient(0f, r - disc, 0f, r - disc * 0.1f, 0x34FFFFFF, 0x00FFFFFF, android.graphics.Shader.TileMode.CLAMP)
            glow = android.graphics.RadialGradient(
                r, r + disc * 0.95f, disc * 0.9f,
                intArrayOf(shade(c, 1.2f, 0x50), shade(c, 1.0f, 0x00)), floatArrayOf(0f, 1f), android.graphics.Shader.TileMode.CLAMP,
            )
            shadow = android.graphics.RadialGradient(r, r + 2 * dp, r, intArrayOf(0x55000000, 0x55000000, 0x00000000), floatArrayOf(0f, 0.78f, 1f), android.graphics.Shader.TileMode.CLAMP)
            clip.reset()
            clip.addCircle(r, r, disc, android.graphics.Path.Direction.CW)
            shadersFor = c
            shadersPinned = pinned
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            shaders()
            // All of it is the lens's to touch, even where it lies over the phone's own
            // swipe-in-from-the-edge zone: a touch there is for the lens and is not a "back".
            if (Build.VERSION.SDK_INT >= 29) systemGestureExclusionRects = listOf(android.graphics.Rect(0, 0, w, h))
        }

        override fun onDraw(canvas: android.graphics.Canvas) {
            // The lens is drawn as it is at its usual size, and scaled to the size it is. While two
            // fingers resize it, that size follows the fingers, and the lens sits in the middle of
            // a window as large as it can get: nothing has to be resized on the way.
            val size = if (stretching) wantSize else width.toFloat()
            val k = size / base
            canvas.save()
            canvas.translate((width - size) / 2f, (height - size) / 2f)
            // Tucked into the side, all but a sliver of it is drawn past the edge. Its window stays
            // on the screen, so the whole of it can still be touched.
            if (tuck > 0f) canvas.translate((if (tuckRight) 1f else -1f) * tuck * (size - 22 * dp * k), 0f)
            canvas.scale(k, k)
            paintLens(canvas, k)
            canvas.restore()
        }

        private fun paintLens(canvas: android.graphics.Canvas, k: Float) {
            if (shadersFor != lensColor() || shadersPinned != !active) shaders()
            val colour = lensColor()
            val w = base; val r = w / 2f
            val disc = r - 5 * dp
            val now = System.currentTimeMillis()
            // A workout shows its timer. A pinned thing shows its picture, and has no timer to read.
            // On a sheet's corner it shows the same, and a tap there folds the sheet away.
            val t = if (active) reading(now) else null
            val go = t != null && t.go
            paint.style = android.graphics.Paint.Style.FILL
            paint.shader = shadow
            canvas.drawCircle(r, r + 2 * dp, r, paint)
            paint.shader = if (go) bodyDone else body
            canvas.drawCircle(r, r, disc, paint)
            canvas.save()
            canvas.clipPath(clip)
            if (!go) {
                paint.shader = glow
                canvas.drawCircle(r, r + disc * 0.95f, disc * 0.9f, paint)
            }
            paint.shader = shine
            canvas.drawOval(r - disc * 1.25f, r - disc * 1.05f, r + disc * 1.25f, r - disc * 0.05f, paint)
            canvas.restore()
            paint.shader = null
            val inset = 5 * dp + 6.5f * dp
            arc.set(inset, inset, w - inset, w - inset)
            if (t != null && t.resting) {
                // The ring: the rest running down, or filling up, with a bright bead at its head.
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = 3.6f * dp
                paint.strokeCap = android.graphics.Paint.Cap.ROUND
                paint.color = 0x24FFFFFF
                canvas.drawArc(arc, 0f, 360f, false, paint)
                paint.color = colour
                canvas.drawArc(arc, -90f, 360f * t.part, false, paint)
                val a = Math.toRadians((-90f + 360f * t.part).toDouble())
                val bx = r + (arc.width() / 2f) * Math.cos(a).toFloat(); val by = r + (arc.height() / 2f) * Math.sin(a).toFloat()
                paint.style = android.graphics.Paint.Style.FILL
                paint.color = shade(colour, 1.3f, 0x55)
                canvas.drawCircle(bx, by, 5.2f * dp, paint)
                paint.color = WHITE
                canvas.drawCircle(bx, by, 2.1f * dp, paint)
            } else if (t != null && !go) {
                // No rest running: a quiet ring with one bead going round once a minute, like a second hand.
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = 2.2f * dp
                paint.color = 0x22FFFFFF
                canvas.drawArc(arc, 0f, 360f, false, paint)
                val a = Math.toRadians((-90.0 + 360.0 * (((now - sinceAt) % 60000L) / 60000.0)))
                paint.style = android.graphics.Paint.Style.FILL
                paint.color = colour
                canvas.drawCircle(r + (arc.width() / 2f) * Math.cos(a).toFloat(), r + (arc.height() / 2f) * Math.sin(a).toFloat(), 2.6f * dp, paint)
            }
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = 1.3f * dp
            paint.shader = rim
            canvas.drawCircle(r, r, disc - 0.65f * dp, paint)
            paint.shader = null
            paint.style = android.graphics.Paint.Style.FILL
            if (t == null) {
                // The pinned thing's picture: its white mark, or its own icon cut round.
                val p = pin
                val bmp = p?.icon
                paint.color = WHITE
                if (p != null && bmp != null) {
                    val half = (if (p.picture) 23f else 19f) * dp
                    dst.set(r - half, r - half, r + half, r + half)
                    paint.isFilterBitmap = true
                    if (p.picture) {
                        round.reset()
                        round.addCircle(r, r, half, android.graphics.Path.Direction.CW)
                        canvas.save()
                        canvas.clipPath(round)
                        canvas.drawBitmap(bmp, null, dst, paint)
                        canvas.restore()
                    } else {
                        canvas.drawBitmap(bmp, null, dst, paint)
                    }
                } else if (p != null && p.name.isNotEmpty()) {
                    paint.textAlign = android.graphics.Paint.Align.CENTER
                    paint.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
                    paint.textSize = 26 * dp
                    canvas.drawText(p.name.substring(0, 1).uppercase(), r, r - (paint.descent() + paint.ascent()) / 2f, paint)
                }
                return // Nothing in it moves, so it is drawn once and left alone.
            }
            paint.color = if (go) onAccent else if (t.urgent) shade(colour, 1.25f, 0xFF) else WHITE
            paint.textAlign = android.graphics.Paint.Align.CENTER
            paint.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            paint.fontFeatureSettings = "tnum"
            paint.letterSpacing = if (go) 0.06f else -0.01f
            paint.textSize = (if (go) 19f else 17.5f) * dp
            canvas.drawText(t.text, r, r - (paint.descent() + paint.ascent()) / 2f, paint)
            if (k > 1.45f && !go) {
                // Made large enough, it has room to say more: what the time is, above it, and
                // which set this is, below.
                val show = ((k - 1.45f) / 0.35f).coerceIn(0f, 1f)
                paint.letterSpacing = 0.08f
                paint.textSize = 4.6f * dp
                paint.color = tint(if (t.resting) shade(colour, 1.25f, 0xFF) else WHITE, (show * 0xD0).toInt())
                canvas.drawText(t.what, r, r - 13.5f * dp, paint)
                paint.letterSpacing = 0f
                paint.textSize = 5.2f * dp
                paint.color = tint(WHITE, (show * 0xB8).toInt())
                canvas.drawText(setLabel, r, r + 18.5f * dp, paint)
            }
            if (go && buzzedFor != endsAt) {
                buzzedFor = endsAt
                haptic(context, "thud")
                animate().scaleX(1.12f).scaleY(1.12f).setDuration(180).setInterpolator(EASE).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(EASE).start()
                }.start()
            }
            // Smooth while a rest is running; otherwise once a second is enough.
            postInvalidateDelayed(if (t.resting) 66 else if (go) 250 else 1000)
        }

        /** Takes the lens to a sheet's corner, or back from it: one even movement, nothing springy. */
        fun glideTo(x: Float, y: Float, ms: Long, size: Int = lp.width) {
            springing = false
            leaving = false
            glide?.cancel()
            val fromX = lp.x.toFloat(); val fromY = lp.y.toFloat()
            val fromSize = lp.width
            val a = android.animation.ValueAnimator.ofFloat(0f, 1f)
            a.duration = ms
            a.interpolator = EASE
            a.addUpdateListener {
                if (isAttachedToWindow) {
                    val f = it.animatedValue as Float
                    lp.x = Math.round(fromX + (x - fromX) * f); lp.y = Math.round(fromY + (y - fromY) * f)
                    if (size != fromSize) {
                        val now = Math.round(fromSize + (size - fromSize) * f)
                        lp.width = now; lp.height = now
                    }
                    place()
                }
            }
            glide = a
            a.start()
        }

        private fun slide(to: Float) {
            tucking?.cancel()
            val a = android.animation.ValueAnimator.ofFloat(tuck, to)
            a.duration = 260
            a.interpolator = EASE
            a.addUpdateListener {
                tuck = it.animatedValue as Float
                invalidate()
            }
            tucking = a
            a.start()
        }

        /** Pushed into a side of the screen and let go: it goes away there, leaving a sliver to see it by. */
        private fun tuckIn(right: Boolean) {
            val screen = resources.displayMetrics
            tucked = true
            tuckRight = right
            target?.held = false
            target?.animate()?.alpha(0f)?.setDuration(200)?.start()
            val y = lp.y.toFloat().coerceIn(48 * dp, Math.max(48 * dp, screen.heightPixels - lp.height - 48 * dp))
            glideTo(if (right) (screen.widthPixels - lp.width).toFloat() else 0f, y, 260)
            slide(1f)
        }

        /** Touched while tucked away: it comes back out to where a lens rests at that side. */
        private fun untuck() {
            val screen = resources.displayMetrics
            haptic(context, "tick")
            tucked = false
            glideTo(if (tuckRight) screen.widthPixels - lp.width - 8 * dp else 8 * dp, lp.y.toFloat(), 260)
            slide(0f)
        }

        private fun rawX(e: android.view.MotionEvent, i: Int): Float =
            if (Build.VERSION.SDK_INT >= 29) e.getRawX(i) else e.getX(i) + (e.rawX - e.getX(0))

        private fun rawY(e: android.view.MotionEvent, i: Int): Float =
            if (Build.VERSION.SDK_INT >= 29) e.getRawY(i) else e.getY(i) + (e.rawY - e.getY(0))

        private fun largest(): Int {
            val screen = resources.displayMetrics
            return Math.max(base.toInt(), minOf(screen.widthPixels, screen.heightPixels) - (16 * dp).toInt())
        }

        /**
         * A second finger, wherever on the screen it is. With the one on the lens it resizes the
         * lens: apart to make it larger, together to make it smaller. The lens stays where it is
         * while they do.
         */
        fun second(down: Boolean, x: Float, y: Float) {
            if (!pressed || docked || tucked) return
            if (!down) {
                sizing = false
                return
            }
            p2x = x; p2y = y
            if (!sizing) {
                sizing = true
                sized = true
                if (!stretching) {
                    // This touch is no longer a drag: the cross goes, and a tap will not follow.
                    stretching = true
                    dragged = true
                    snapped = false
                    wouldTuck = false
                    springing = false
                    glide?.cancel()
                    target?.held = false
                    target?.animate()?.alpha(0f)?.setDuration(160)?.start()
                    animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    haptic(context, "tick")
                    wantSize = lp.width.toFloat()
                    midX = lp.x + lp.width / 2f; midY = lp.y + lp.height / 2f
                    val big = largest()
                    lp.width = big; lp.height = big
                    lp.x = Math.round(midX - big / 2f); lp.y = Math.round(midY - big / 2f)
                    place()
                }
                startDist = Math.max(Math.hypot((p1x - p2x).toDouble(), (p1y - p2y).toDouble()).toFloat(), 40 * dp)
                startSize = wantSize
            }
            stretch()
        }

        private fun stretch() {
            if (!sizing) return
            val apart = Math.hypot((p1x - p2x).toDouble(), (p1y - p2y).toDouble()).toFloat()
            val least = base; val most = largest().toFloat()
            val want = startSize * apart / startDist
            // A click where it will go no further, either way.
            val end = want <= least || want >= most
            if (end && !atEnd) haptic(context, "click")
            atEnd = end
            val now = want.coerceIn(least, most)
            if (now != wantSize) {
                wantSize = now
                invalidate()
            }
        }

        /** The fingers are off: the lens keeps the size it was given, and settles at the nearer side. */
        private fun endStretch() {
            pressed = false
            sizing = false
            sized = false
            closeReach(context)
            tracker?.recycle()
            tracker = null
            if (!stretching) return
            stretching = false
            val size = Math.round(wantSize)
            lp.width = size; lp.height = size
            lp.x = Math.round(midX - size / 2f); lp.y = Math.round(midY - size / 2f)
            place()
            lensSize = size
            try {
                context.getSharedPreferences("prism_lens", Context.MODE_PRIVATE).edit().putFloat("size", size / dp).apply()
            } catch (ex: Exception) {}
            throwIt(0f, 0f)
        }

        private fun place() {
            // Its place on a sheet's corner is not where it lives; only its own place is remembered.
            if (!docked) {
                lensX = lp.x; lensY = lp.y
            }
            try { (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).updateViewLayout(this, lp) } catch (ex: Exception) {}
        }

        /** The middle of the cross, on the screen. */
        private fun crossX() = resources.displayMetrics.widthPixels / 2f
        private fun crossY() = resources.displayMetrics.heightPixels - 104 * dp

        // A firm spring for a thrown lens: it carries on a little with the throw and comes to rest
        // without bouncing.
        private val frame = object : android.view.Choreographer.FrameCallback {
            override fun doFrame(nanos: Long) {
                if (!springing || !isAttachedToWindow) { springing = false; return }
                val dt = if (lastFrame == 0L) 1f / 120f else ((nanos - lastFrame) / 1e9f).coerceIn(0.001f, 0.032f)
                lastFrame = nanos
                val k = if (leaving) 320f else 240f; val c = if (leaving) 30f else 28f
                vx += (-k * (px - tx) - c * vx) * dt; px += vx * dt
                vy += (-k * (py - ty) - c * vy) * dt; py += vy * dt
                lp.x = px.toInt(); lp.y = py.toInt()
                place()
                val near = if (leaving) 6f else 0.6f
                val still = Math.abs(px - tx) < near && Math.abs(py - ty) < near && (leaving || (Math.abs(vx) < 12f && Math.abs(vy) < 12f))
                if (still) {
                    springing = false
                    if (leaving) close()
                } else {
                    android.view.Choreographer.getInstance().postFrameCallback(this)
                }
            }
        }

        /**
         * Dropped on the cross. The lens falls into it and the cross swallows it. A workout's lens
         * then stays away until the workout page is opened; a pinned thing is unpinned.
         */
        private fun close() {
            haptic(context, "thud")
            val c = context
            val wasWorkout = active
            val colour = lensColor()
            animate().scaleX(0f).scaleY(0f).setDuration(210).setInterpolator(android.view.animation.AccelerateInterpolator(1.6f)).start()
            val finish: () -> Unit = {
                if (wasWorkout) {
                    dismissed = true
                } else {
                    pin = null
                    channel?.invokeMethod("unpinned", null)
                }
                // It comes back at its usual place, not on the cross.
                lensX = -1; lensY = -1
                tucked = false
                refresh(c)
            }
            val t = target
            if (t != null) t.swallow(colour, finish) else finish()
        }

        private fun throwIt(velX: Float, velY: Float) {
            val screen = resources.displayMetrics
            val margin = 8 * dp
            glide?.cancel()
            px = lp.x.toFloat(); py = lp.y.toFloat(); vx = velX; vy = velY
            // Where it would coast to decides where it ends up, so a flick carries it.
            val coastX = px + velX * 0.16f
            val coastY = py + velY * 0.18f
            // A flick down toward the middle is a throw at the cross.
            val w = lp.width; val h = lp.height
            val atCross = velY > 700 && coastY + h / 2f > screen.heightPixels * 0.70f && Math.abs(coastX + w / 2f - crossX()) < 120 * dp
            leaving = snapped || atCross
            if (leaving) {
                tx = crossX() - w / 2f; ty = crossY() - h / 2f
                target?.held = true
            } else {
                tx = if (coastX + w / 2f < screen.widthPixels / 2f) margin else screen.widthPixels - w - margin
                ty = coastY.coerceIn(48 * dp, Math.max(48 * dp, screen.heightPixels - h - 48 * dp))
                target?.held = false
                target?.animate()?.alpha(0f)?.setDuration(200)?.start()
            }
            lastFrame = 0L
            if (!springing) {
                springing = true
                android.view.Choreographer.getInstance().postFrameCallback(frame)
            }
        }

        override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
            if (docked) {
                // On a sheet's corner it is one thing only: the button that folds the sheet away.
                when (e.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                    android.view.MotionEvent.ACTION_UP -> {
                        animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(EASE).start()
                        haptic(context, "tick")
                        closeSheet(context)
                    }
                    android.view.MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(160).start()
                }
                return true
            }
            if (e.actionMasked == android.view.MotionEvent.ACTION_DOWN) ignoring = false
            if (ignoring) return true
            if (tucked) {
                // Tucked away, a touch anywhere on it does one thing: it brings the lens back out.
                when (e.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        if (Math.hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) > 12 * dp) {
                            ignoring = true
                            untuck()
                        }
                    }
                    android.view.MotionEvent.ACTION_UP -> {
                        ignoring = true
                        untuck()
                    }
                }
                return true
            }
            p1x = e.rawX; p1y = e.rawY
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_POINTER_DOWN -> {
                    // A second finger, on a phone that sends it to the lens wherever it lands.
                    if (e.pointerCount >= 2) second(true, rawX(e, 1), rawY(e, 1))
                    return true
                }
                android.view.MotionEvent.ACTION_POINTER_UP -> {
                    second(false, 0f, 0f)
                    return true
                }
            }
            if (sized) {
                // Two fingers are resizing it, or were: this touch no longer moves it or taps it.
                when (e.actionMasked) {
                    android.view.MotionEvent.ACTION_MOVE -> {
                        if (sizing && e.pointerCount >= 2) {
                            p2x = rawX(e, 1); p2y = rawY(e, 1)
                        }
                        stretch()
                    }
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> endStretch()
                }
                return true
            }
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    pressed = true
                    sizing = false
                    atEnd = false
                    // From now until the finger lifts, a second finger anywhere resizes the lens.
                    openReach(context)
                    springing = false
                    leaving = false
                    wouldTuck = false
                    glide?.cancel()
                    tracker?.recycle()
                    tracker = android.view.VelocityTracker.obtain()
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; dragged = false; snapped = false
                    animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    val slop = 10 * dp
                    if (!dragged && dx * dx + dy * dy > slop * slop) {
                        dragged = true
                        // The cross appears as soon as the lens is picked up.
                        target?.animate()?.alpha(1f)?.setDuration(160)?.start()
                    }
                    if (dragged) {
                        var x = startX + dx; var y = startY + dy
                        // Near the cross the lens is pulled onto it, and lets go again if dragged clear.
                        val cx = x + width / 2f; val cy = y + height / 2f
                        val dist = Math.hypot((cx - crossX()).toDouble(), (cy - crossY()).toDouble()).toFloat()
                        val was = snapped
                        snapped = dist < (if (snapped) 118 else 92) * dp
                        if (snapped) {
                            x = crossX() - width / 2f + (cx - crossX()) * 0.18f
                            y = crossY() - height / 2f + (cy - crossY()) * 0.18f
                        }
                        if (snapped != was) {
                            haptic(context, if (snapped) "click" else "tick")
                            target?.held = snapped
                        }
                        lp.x = x.toInt(); lp.y = y.toInt()
                        place()
                        // Pushed a quarter of the way past a side, letting go tucks it away there. A tick says so.
                        val past = 0.25f * lp.width
                        val would = !snapped && (lp.x < -past || lp.x + lp.width > resources.displayMetrics.widthPixels + past)
                        if (would != wouldTuck) {
                            wouldTuck = would
                            haptic(context, "tick")
                        }
                    }
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    pressed = false
                    closeReach(context)
                    animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(EASE).start()
                    if (e.actionMasked == android.view.MotionEvent.ACTION_UP && !dragged) {
                        haptic(context, "tick")
                        // Tapped. A workout opens its sheet; a pinned thing does what it is.
                        if (active) openSheet(context) else tapPinned(context)
                    } else if (e.actionMasked == android.view.MotionEvent.ACTION_UP && wouldTuck) {
                        tuckIn(lp.x + lp.width / 2f > resources.displayMetrics.widthPixels / 2f)
                    } else {
                        var velX = 0f; var velY = 0f
                        val t = tracker
                        if (t != null) {
                            t.computeCurrentVelocity(1000)
                            velX = t.xVelocity; velY = t.yVelocity
                        }
                        throwIt(velX, velY)
                    }
                    tracker?.recycle()
                    tracker = null
                }
            }
            // Positions on the screen, not in the lens, which moves under the finger.
            val copy = android.view.MotionEvent.obtain(e)
            copy.setLocation(e.rawX, e.rawY)
            tracker?.addMovement(copy)
            copy.recycle()
            return true
        }
    }

    /** The timer in the sheet: a ring with the time in it. */
    private class Clock(context: Context) : android.view.View(context) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val arc = android.graphics.RectF()
        private val dp = resources.displayMetrics.density

        override fun onDraw(canvas: android.graphics.Canvas) {
            val w = width.toFloat(); val r = w / 2f
            val now = System.currentTimeMillis()
            val t = reading(now)
            val stroke = Math.max(3.5f * dp, w * 0.055f)
            arc.set(stroke, stroke, w - stroke, w - stroke)
            paint.shader = null
            if (t.go) {
                paint.style = android.graphics.Paint.Style.FILL
                paint.color = accent
                canvas.drawCircle(r, r, r - stroke / 2, paint)
            } else {
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = stroke
                paint.strokeCap = android.graphics.Paint.Cap.ROUND
                paint.color = tint(ink(), 0x22)
                canvas.drawArc(arc, 0f, 360f, false, paint)
                paint.color = accent
                if (t.resting) {
                    canvas.drawArc(arc, -90f, 360f * t.part, false, paint)
                } else {
                    val a = Math.toRadians((-90.0 + 360.0 * (((now - sinceAt) % 60000L) / 60000.0)))
                    paint.style = android.graphics.Paint.Style.FILL
                    canvas.drawCircle(r + (arc.width() / 2f) * Math.cos(a).toFloat(), r + (arc.height() / 2f) * Math.sin(a).toFloat(), stroke * 0.8f, paint)
                }
            }
            paint.style = android.graphics.Paint.Style.FILL
            paint.color = if (t.go) onAccent else if (t.urgent) shade(accent, 1.25f, 0xFF) else ink()
            paint.textAlign = android.graphics.Paint.Align.CENTER
            paint.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            paint.fontFeatureSettings = "tnum"
            paint.textSize = w * 0.27f
            canvas.drawText(t.text, r, r - (paint.descent() + paint.ascent()) / 2f, paint)
            postInvalidateDelayed(if (t.resting) 50 else 500)
        }
    }

    /**
     * A thumb dial, the same as the ones on Prism's workout page: drag sideways and the number
     * turns under the thumb with a click for every step; slow down and it changes to fine
     * steps with a different click; a tap on either half nudges it one step.
     */
    private class Dial(context: Context, val unit: String, val step: Double, val fine: Double, val min: Double, val max: Double) : android.view.View(context) {
        var value = 0.0
            set(v) {
                if (field != v) {
                    field = v
                    invalidate()
                }
            }
        var onChange: ((Double) -> Unit)? = null
        var dragging = false
        private val dp = resources.displayMetrics.density
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val box = android.graphics.RectF()
        private var downX = 0f; private var lastX = 0f; private var lastT = 0L
        private var raw = 0.0; private var wheel = 0f; private var speed = 0f
        private var fineNow = false; private var slowSince = 0L
        private var moved = false

        private fun snap(v: Double, s: Double) = (Math.round(v / s) * s).coerceIn(min, max)

        private fun emit(v: Double) {
            if (v != value) {
                value = v
                haptic(context, "tick")
                onChange?.invoke(v)
            }
        }

        override fun onDraw(canvas: android.graphics.Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            box.set(1 * dp, 1 * dp, w - 1 * dp, h - 1 * dp)
            paint.shader = null
            paint.style = android.graphics.Paint.Style.FILL
            paint.color = if (dragging) tint(accent, 0x2E) else tint(ink(), 0x14)
            canvas.drawRoundRect(box, h / 2, h / 2, paint)
            if (dragging) {
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = 1.5f * dp
                paint.color = accent
                canvas.drawRoundRect(box, h / 2, h / 2, paint)
            }
            // The edge of a wheel seen side-on: ticks bunch up and fade toward the sides, and turn with the thumb.
            val cx = w / 2
            val radius = w / 2 - 12 * dp
            val gap = 0.21
            val turn = ((wheel / radius) % gap + gap) % gap
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeCap = android.graphics.Paint.Cap.ROUND
            paint.strokeWidth = (if (fineNow) 1.1f else 1.6f) * dp
            val base = if (dragging) accent else muted()
            var k = -8
            while (k <= 8) {
                val a = k * gap + turn
                if (Math.abs(a) < 1.45) {
                    val x = cx + radius * Math.sin(a).toFloat()
                    paint.color = tint(base, (150 * Math.cos(a)).toInt().coerceIn(0, 255))
                    canvas.drawLine(x, h - 7 * dp - 5 * dp, x, h - 7 * dp, paint)
                }
                k++
            }
            // The number, with its unit small beside it.
            val num = number(value)
            paint.style = android.graphics.Paint.Style.FILL
            paint.textAlign = android.graphics.Paint.Align.LEFT
            paint.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            paint.fontFeatureSettings = "tnum"
            paint.textSize = 20 * dp
            val wn = paint.measureText(num)
            val baseline = h / 2 - 5 * dp - (paint.descent() + paint.ascent()) / 2f
            paint.textSize = 12 * dp
            val wu = paint.measureText(unit)
            val x0 = cx - (wn + 4 * dp + wu) / 2
            paint.textSize = 20 * dp
            paint.color = ink()
            canvas.drawText(num, x0, baseline, paint)
            paint.textSize = 12 * dp
            paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            paint.color = muted()
            canvas.drawText(unit, x0 + wn + 4 * dp, baseline, paint)
        }

        private fun end() {
            dragging = false
            fineNow = false
            moved = false
            invalidate()
        }

        override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
            if (!isEnabled) return false
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = e.x; lastX = e.x; lastT = e.eventTime
                    raw = value
                    speed = 240f * dp // starts in whole steps; slowing down is what selects fine ones
                    fineNow = false; slowSince = 0L; moved = false
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (!moved) {
                        if (Math.abs(e.x - downX) > 8 * dp) {
                            moved = true
                            dragging = true
                            parent?.requestDisallowInterceptTouchEvent(true)
                            lastX = e.x; lastT = e.eventTime
                            invalidate()
                        }
                    } else {
                        val dx = e.x - lastX
                        val dt = (e.eventTime - lastT) / 1000f
                        if (dt > 0) speed += (Math.abs(dx) / dt - speed) * 0.3f
                        if (speed < 45 * dp) {
                            if (slowSince == 0L) slowSince = e.eventTime
                            if (!fineNow && fine < step && e.eventTime - slowSince >= 120) {
                                fineNow = true
                                raw = value // fine steps start from the number on screen
                                haptic(context, "click") // a different click: "fine steps now"
                            }
                        } else {
                            slowSince = 0L
                            if (fineNow && speed > 160 * dp) fineNow = false
                        }
                        val s = if (fineNow) fine else step
                        raw = (raw + dx / (16 * dp) * s).coerceIn(min, max)
                        wheel += dx
                        lastX = e.x; lastT = e.eventTime
                        emit(snap(raw, s))
                        invalidate()
                    }
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (!moved) emit(snap(value + (if (e.x < width / 2f) -step else step), fine))
                    end()
                }
                android.view.MotionEvent.ACTION_CANCEL -> end()
            }
            return true
        }
    }

    /** The round tick at the end of a set's row. */
    private class Tick(context: Context) : android.view.View(context) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val check = android.graphics.Path()
        private val dp = resources.displayMetrics.density
        var done = false
            set(v) {
                if (field != v) {
                    field = v
                    invalidate()
                }
            }

        override fun onDraw(canvas: android.graphics.Canvas) {
            val c = width / 2f; val cy = height / 2f
            val r = 21 * dp
            paint.style = if (done) android.graphics.Paint.Style.FILL else android.graphics.Paint.Style.STROKE
            paint.strokeWidth = 2 * dp
            paint.color = if (done) GREEN else tint(ink(), 0x66)
            canvas.drawCircle(c, cy, r - 1 * dp, paint)
            check.reset()
            check.moveTo(c - 8 * dp, cy + 0.5f * dp)
            check.lineTo(c - 2.5f * dp, cy + 6 * dp)
            check.lineTo(c + 8.5f * dp, cy - 5.5f * dp)
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = 2.6f * dp
            paint.strokeCap = android.graphics.Paint.Cap.ROUND
            paint.strokeJoin = android.graphics.Paint.Join.ROUND
            paint.color = if (done) 0xFFFFFFFF.toInt() else tint(ink(), 0x66)
            canvas.drawPath(check, paint)
        }
    }

    /** The grabber at the top of a sheet: a shallow arrow in the colour, pointing the way the sheet can go. */
    private class Grab(context: Context) : android.view.View(context) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val path = android.graphics.Path()
        private val dp = resources.displayMetrics.density
        // How far it is bent, and which way: 1 is toward the bottom, -1 toward the top.
        private var bend = 1f
        private var turning: android.animation.ValueAnimator? = null
        var up = false
            set(v) {
                if (field != v) {
                    field = v
                    val to = if (v) -1f else 1f
                    turning?.cancel()
                    if (isLaidOut) {
                        // It bends over to the other side; it does not flip.
                        val a = android.animation.ValueAnimator.ofFloat(bend, to)
                        a.duration = 280
                        a.interpolator = EASE
                        a.addUpdateListener {
                            bend = it.animatedValue as Float
                            invalidate()
                        }
                        turning = a
                        a.start()
                    } else {
                        bend = to
                        invalidate()
                    }
                }
            }

        override fun onDraw(canvas: android.graphics.Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            // Wide, with a slight bend at the middle: toward the top when the sheet can be pulled up.
            val w = 31 * dp
            val h = 3.4f * dp * bend
            path.reset()
            path.moveTo(cx - w, cy - h)
            path.lineTo(cx, cy + h)
            path.lineTo(cx + w, cy - h)
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = 4.4f * dp
            paint.strokeCap = android.graphics.Paint.Cap.ROUND
            paint.strokeJoin = android.graphics.Paint.Join.ROUND
            paint.color = accent
            canvas.drawPath(path, paint)
        }
    }

    /**
     * Which set this is and how many there are, at a glance: one segment for each set, the same
     * bar the workout page draws for its exercises. Done is green, the one in hand is in the
     * colour, the rest are faint. The warm-up is the short one at the start.
     */
    private class Pips(context: Context) : android.view.View(context) {
        private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val dp = resources.displayMetrics.density

        override fun onDraw(canvas: android.graphics.Canvas) {
            val n = sets.size
            if (n == 0) return
            val gap = 5 * dp
            val h = height.toFloat()
            val short = 0.34f
            val unit = (width - gap * (n - 1)) / ((n - 1) + short)
            var x = 0f
            for (i in 0 until n) {
                val w = if (i == 0) unit * short else unit
                paint.color = when {
                    sets[i].done -> GREEN
                    i == current -> accent
                    else -> tint(ink(), 0x30)
                }
                canvas.drawRoundRect(x, 0f, x + w, h, h / 2f, h / 2f, paint)
                x += w + gap
            }
        }
    }

    private class Row(val root: android.widget.LinearLayout, val name: android.widget.TextView, val kg: Dial, val reps: Dial, val tick: Tick)

    /**
     * A sheet at the bottom of the screen. Every floating sheet is one of these, so they all
     * arrive, lean, settle and leave the same way: a glass card with a grabber, which follows a
     * downward pull, folds away on a touch outside, and tells its owner when it has been pulled
     * down or up.
     */
    private abstract class Sheet(context: Context) : android.widget.FrameLayout(context) {
        protected val dp = resources.displayMetrics.density
        protected fun px(v: Float) = (v * dp).toInt()
        protected val wrap = android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
        protected val fill = android.widget.LinearLayout.LayoutParams.MATCH_PARENT
        protected val card = android.widget.LinearLayout(context)
        protected val grab = Grab(context)
        private val grabBox = android.widget.FrameLayout(context)
        // Nearly solid, with a lit edge. It cannot blur what is underneath, and text showing
        // through unblurred only got in the way of reading the sheet.
        private val glass = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            if (light) intArrayOf(0xFBFFFDF8.toInt(), 0xFAF3EEE4.toInt()) else intArrayOf(0xF81C1F27.toInt(), 0xFA0E0F13.toInt()),
        )
        // How far below the top of [body] the glass starts: nothing, except while the sheet is changing size.
        private var edge = 0
        // What was on the glass before a change of size, fading away where it stood.
        private var ghost: android.graphics.Bitmap? = null
        private var ghostAlpha = 0f
        private var ghostTop = 0
        private val ghostPaint = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)

        /** The glass and everything on it. This is what comes up, drops away and follows a pull. */
        protected val body: android.widget.FrameLayout = object : android.widget.FrameLayout(context) {
            override fun onDraw(canvas: android.graphics.Canvas) {
                glass.setBounds(0, edge, width, height)
                glass.draw(canvas)
            }

            override fun dispatchDraw(canvas: android.graphics.Canvas) {
                super.dispatchDraw(canvas)
                val g = ghost
                if (g != null && ghostAlpha > 0.004f) {
                    ghostPaint.alpha = (ghostAlpha * 255).toInt()
                    canvas.drawBitmap(g, 0f, ghostTop.toFloat(), ghostPaint)
                }
            }
        }
        private var downX = 0f
        private var downY = 0f
        private var pulling = false
        private var tracker: android.view.VelocityTracker? = null
        protected var closing = false
            private set

        // A change of size under way.
        private var morphing: android.animation.ValueAnimator? = null
        protected var changing = false
            private set
        private var part = 1f
        private var glassFrom = 0f
        private var glassNow = 0f
        private var through: List<android.view.View> = emptyList()
        private var riders: List<android.view.View> = emptyList()
        private var steady: android.view.View? = null
        private var docking = false
        private var morphMs = 300L

        init {
            // A little room above the glass, so it can lean past its place when pulled up. Kept small:
            // this strip belongs to the sheet's window, and the lens sits just above it.
            setPadding(0, px(8f), 0, 0)
            clipChildren = false
            clipToPadding = false
            card.orientation = android.widget.LinearLayout.VERTICAL
            card.setPadding(px(14f), px(4f), px(14f), px(14f))
            card.clipChildren = false
            card.clipToPadding = false
            glass.cornerRadius = 32 * dp
            glass.setStroke(px(1.2f), if (light) 0x24000000 else 0x40FFFFFF)
            // The glass is drawn by [body], and everything on it is cut to the glass's shape, so
            // that nothing shows past its top edge while that edge is moving.
            body.setWillNotDraw(false)
            body.clipChildren = false
            body.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: android.view.View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, edge, view.width, view.height, 32 * dp)
                }
            }
            body.clipToOutline = true
            body.addView(card, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, android.view.Gravity.BOTTOM))
            addView(body, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
            // The grabber: pull it, or tap it. An arrow in the colour, pointing the way the sheet can go.
            grabBox.addView(grab, LayoutParams(px(88f), px(24f), android.view.Gravity.CENTER))
            grabBox.setOnClickListener { tappedGrabber() }
            card.addView(grabBox, android.widget.LinearLayout.LayoutParams(fill, px(30f)))
            // The lens keeps to this sheet's corner: it is told as soon as the sheet has a size, or a new one.
            addOnLayoutChangeListener { _, left, top, right, bottom, wasLeft, wasTop, wasRight, wasBottom ->
                if (right - left != wasRight - wasLeft || bottom - top != wasBottom - wasTop) post { dock(context) }
            }
        }

        // Keeps the lens on this sheet's corner while the sheet is open, wherever the sheet goes.
        private val keeper = object : Runnable {
            override fun run() {
                if (sheet !== this@Sheet) return
                dock(context)
                postDelayed(this, 200)
            }
        }

        // While the sheet is changing size, everything is put in its place after layout and
        // before each frame is drawn.
        private val beforeDraw = android.view.ViewTreeObserver.OnPreDrawListener {
            if (morphing != null) pose()
            true
        }

        /** Pulled or flicked down. */
        abstract fun pulledDown()

        /** Pulled or flicked up. False if there is nothing taller for it to become. */
        open fun pulledUp(): Boolean = false

        open fun tappedGrabber() {}

        /** Brings what is shown up to date. */
        open fun sync() {}

        /** Where the top of the glass is, or is on its way to, measured from the top of this sheet's window. */
        fun glassTop(): Int = body.top + body.height - card.height

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            viewTreeObserver.addOnPreDrawListener(beforeDraw)
        }

        override fun onDetachedFromWindow() {
            viewTreeObserver.removeOnPreDrawListener(beforeDraw)
            stopMorph(false)
            super.onDetachedFromWindow()
        }

        /** It comes up a short way into its place. */
        open fun arrive() {
            body.translationY = 26 * dp
            body.alpha = 0f
            body.animate().translationY(0f).alpha(1f).setDuration(300).setInterpolator(EASE).start()
            post(keeper)
        }

        /** It drops a little and is gone. What it shows stays as it was while it goes. */
        fun leave(then: () -> Unit) {
            if (closing) return
            closing = true
            var gone = false
            val finish = Runnable {
                if (!gone) {
                    gone = true
                    then()
                }
            }
            body.animate().translationY(body.translationY + 16 * dp).alpha(0f).setDuration(150)
                .setInterpolator(android.view.animation.AccelerateInterpolator(1.2f)).withEndAction(finish).start()
            // Whatever becomes of that movement, the sheet goes.
            postDelayed(finish, 320)
        }

        /**
         * Changes the sheet's size in one even movement. The top edge of the glass travels to its
         * new place. [fade] is what is swapped on the way: what was there goes first, what
         * replaces it comes after. [ride] keeps its place under the edge as that moves. [keep]
         * is the thing at the bottom that stays exactly as it is.
         */
        protected fun morph(ms: Long, fade: List<android.view.View>, ride: List<android.view.View>, keep: android.view.View?, change: () -> Unit) {
            if (!isLaidOut || card.height == 0 || closing || (changing && morphing == null)) {
                change()
                return
            }
            val again = morphing != null
            val from = if (again) glassNow else card.height.toFloat()
            stopMorph(false)
            changing = true
            ghost = if (!again && fade.isNotEmpty()) snapshot(fade, keep?.top ?: card.height) else null
            // The window keeps its height until the glass has finished moving inside it.
            body.minimumHeight = body.height
            through = fade
            riders = ride
            steady = keep
            glassFrom = from
            part = 0f
            morphMs = ms
            docking = true
            change()
            body.animate().translationY(0f).setDuration(ms).setInterpolator(EASE).start()
            val a = android.animation.ValueAnimator.ofFloat(0f, 1f)
            a.duration = ms
            a.interpolator = android.view.animation.LinearInterpolator()
            a.addUpdateListener {
                part = it.animatedValue as Float
                body.invalidate()
            }
            a.addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (morphing === animation) stopMorph(true)
                }
            })
            morphing = a
            a.start()
        }

        /** Puts everything where it belongs at this moment of a change of size. */
        private fun pose() {
            val to = card.height.toFloat()
            glassNow = glassFrom + (to - glassFrom) * EASE.getInterpolation(part)
            edge = Math.round(body.height - glassNow).coerceAtLeast(0)
            val off = (edge - card.top).toFloat()
            grabBox.translationY = off
            for (v in riders) v.translationY = off
            // What was there goes first and quickly; what replaces it comes up after.
            ghostAlpha = 1f - smooth(part / 0.34f)
            ghostTop = card.top + (steady?.top ?: card.height) - (ghost?.height ?: 0)
            val shown = smooth((part - 0.22f) / 0.6f)
            for (v in through) v.alpha = shown
            body.invalidate()
            body.invalidateOutline()
            if (docking) {
                // The lens sets off for the corner's new place with the edge, and takes as long.
                docking = false
                dock(context, morphMs)
            }
        }

        private fun stopMorph(release: Boolean) {
            val a = morphing
            morphing = null
            changing = false
            if (a != null) {
                a.removeAllListeners()
                a.removeAllUpdateListeners()
                a.cancel()
            }
            grabBox.translationY = 0f
            for (v in riders) v.translationY = 0f
            for (v in through) v.alpha = 1f
            riders = emptyList()
            through = emptyList()
            steady = null
            ghost = null
            ghostAlpha = 0f
            if (release) {
                edge = 0
                body.minimumHeight = 0
            }
            body.invalidate()
            body.invalidateOutline()
        }

        /** A picture of [views] as they stand, from the top of the card down to [until]. */
        private fun snapshot(views: List<android.view.View>, until: Int): android.graphics.Bitmap? {
            if (card.width <= 0 || until <= 0) return null
            return try {
                val b = android.graphics.Bitmap.createBitmap(card.width, until, android.graphics.Bitmap.Config.ARGB_8888)
                val c = android.graphics.Canvas(b)
                for (v in views) {
                    if (v.visibility != android.view.View.VISIBLE) continue
                    c.save()
                    c.translate(v.left.toFloat(), v.top.toFloat())
                    v.draw(c)
                    c.restore()
                }
                b
            } catch (e: Throwable) {
                null
            }
        }

        private fun settle() {
            body.animate().translationY(0f).setDuration(240).setInterpolator(EASE).start()
        }

        override fun dispatchTouchEvent(e: android.view.MotionEvent): Boolean {
            // A touch anywhere outside folds it away; the touch still reaches what is underneath.
            if (e.actionMasked == android.view.MotionEvent.ACTION_OUTSIDE) {
                closeSheet(context)
                return true
            }
            // On its way out it takes no more touches.
            if (closing) return true
            return super.dispatchTouchEvent(e)
        }

        private fun watch(e: android.view.MotionEvent) {
            val copy = android.view.MotionEvent.obtain(e)
            copy.setLocation(e.rawX, e.rawY)
            tracker?.addMovement(copy)
            copy.recycle()
        }

        private fun startsPull(e: android.view.MotionEvent): Boolean {
            val dx = e.rawX - downX
            val dy = e.rawY - downY
            return Math.abs(dy) > 10 * dp && Math.abs(dy) > Math.abs(dx) * 1.3f
        }

        // An up-or-down drag that starts anywhere on the sheet, even on a dial, moves the sheet.
        override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; pulling = false
                    tracker?.recycle()
                    tracker = android.view.VelocityTracker.obtain()
                    watch(e)
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    watch(e)
                    if (!pulling && startsPull(e)) {
                        pulling = true
                        return true
                    }
                }
            }
            return false
        }

        override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_MOVE -> {
                    watch(e)
                    if (!pulling && startsPull(e)) pulling = true
                    if (pulling) {
                        val dy = e.rawY - downY
                        // Down, it follows the finger. Up, it only leans.
                        body.translationY = if (dy > 0) dy else -Math.min(7 * dp, -dy * 0.12f)
                    }
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    watch(e)
                    var vy = 0f
                    val t = tracker
                    if (t != null) {
                        t.computeCurrentVelocity(1000)
                        vy = t.yVelocity
                    }
                    tracker?.recycle()
                    tracker = null
                    if (pulling) {
                        val dy = e.rawY - downY
                        when {
                            dy > 70 * dp || vy > 1100 -> {
                                haptic(context, "tick")
                                pulledDown()
                            }
                            dy < -36 * dp || vy < -1100 -> {
                                if (pulledUp()) haptic(context, "tick") else settle()
                            }
                            else -> settle()
                        }
                    }
                    pulling = false
                }
            }
            return true
        }
    }

    /** The workout's sheet, in two sizes: the current set, or the whole exercise with a large timer. */
    private class WorkoutSheet(context: Context) : Sheet(context) {
        private val header = android.widget.LinearLayout(context)
        private val clock = Clock(context)
        private val info = android.widget.LinearLayout(context)
        private val what = label(context, 11.5f, muted(), true)
        private val name = label(context, 18f, ink(), true)
        private val which = label(context, 12.5f, muted(), false)
        private val controls = android.widget.LinearLayout(context)
        private val add = label(context, 13f, ink(), true)
        private val skip = label(context, 13f, ink(), true)
        private val open = label(context, 13f, ink(), true)
        private val pips = Pips(context)
        private val rows = android.widget.LinearLayout(context)
        private val rowViews = ArrayList<Row>()
        private val done = label(context, 16.5f, onAccent, true)

        private val ticker = object : Runnable {
            override fun run() {
                if (sheet !== this@WorkoutSheet) return
                texts()
                postDelayed(this, 250)
            }
        }

        init {
            // The timer. A tap on it switches between counting down and counting up.
            val switchMode = android.view.View.OnClickListener {
                haptic(context, "click")
                countUp = !countUp
                channel?.invokeMethod("timerMode", null)
                texts()
                clock.invalidate()
                view?.invalidate()
            }
            clock.setOnClickListener(switchMode)
            what.letterSpacing = 0.08f
            what.maxLines = 1
            name.maxLines = 1
            what.setOnClickListener(switchMode)
            what.setPadding(0, px(4f), 0, px(4f))
            info.orientation = android.widget.LinearLayout.VERTICAL
            info.addView(what)
            info.addView(name)
            val whichLp = android.widget.LinearLayout.LayoutParams(wrap, wrap)
            whichLp.topMargin = px(2f)
            info.addView(which, whichLp)

            // [click] is false where Prism does the thing and gives its own click for it.
            fun pill(t: android.widget.TextView, text: String, click: Boolean, action: () -> Unit) {
                t.text = text
                t.setPadding(px(14f), px(10f), px(14f), px(10f))
                t.background = rounded(tint(ink(), 0x1F), 100 * dp)
                t.setOnClickListener {
                    if (click) haptic(context, "tick")
                    action()
                }
            }
            pill(add, "+15 s", false) { channel?.invokeMethod("restAdd", null) }
            pill(skip, "Skip", false) { channel?.invokeMethod("restSkip", null) }
            pill(open, "Open workout", true) { openPrism(context) }
            controls.gravity = android.view.Gravity.CENTER_VERTICAL
            val gapLp = { android.widget.LinearLayout.LayoutParams(wrap, wrap).also { it.leftMargin = px(8f) } }
            controls.addView(add, android.widget.LinearLayout.LayoutParams(wrap, wrap))
            controls.addView(skip, gapLp())
            controls.addView(open, gapLp())

            header.addView(clock)
            header.addView(info)
            header.addView(controls)
            card.addView(header, android.widget.LinearLayout.LayoutParams(fill, wrap))

            // The small sheet shows one set; this bar says which one it is, out of how many.
            val pipsLp = android.widget.LinearLayout.LayoutParams(fill, px(5f))
            pipsLp.topMargin = px(13f)
            pipsLp.leftMargin = px(4f)
            pipsLp.rightMargin = px(4f)
            card.addView(pips, pipsLp)

            rows.orientation = android.widget.LinearLayout.VERTICAL
            val rowsLp = android.widget.LinearLayout.LayoutParams(fill, wrap)
            rowsLp.topMargin = px(12f)
            card.addView(rows, rowsLp)

            done.gravity = android.view.Gravity.CENTER
            done.setOnClickListener {
                // No click here: Prism logs the set and gives the same click it gives on its own page.
                if (current in sets.indices) channel?.invokeMethod("toggle", current)
                // Logging is the errand: the sheet folds away, in either size, and the lens shows the rest.
                closeSheet(context)
            }
            val doneLp = android.widget.LinearLayout.LayoutParams(fill, px(56f))
            doneLp.topMargin = px(10f)
            card.addView(done, doneLp)

            applyMode()
        }

        override fun arrive() {
            super.arrive()
            postDelayed(ticker, 250)
            if (!fullMode) {
                // The arrow lifts once, gently, as the small sheet arrives: there is more above.
                grab.animate().translationY(-4 * dp).setStartDelay(380).setDuration(260).setInterpolator(EASE).withEndAction {
                    grab.animate().translationY(0f).setStartDelay(0).setDuration(420)
                        .setInterpolator(android.view.animation.AccelerateDecelerateInterpolator()).start()
                }.start()
            }
        }

        /** Becomes the small sheet or the tall one. The button at the bottom stays as it is throughout. */
        private fun resize(full: Boolean) {
            fullMode = full
            morph(340, listOf(header, pips, rows), emptyList(), done) { applyMode() }
        }

        // Down: the tall sheet becomes the small one; the small one becomes the lens.
        override fun pulledDown() {
            if (fullMode) resize(false) else closeSheet(context)
        }

        override fun pulledUp(): Boolean {
            if (fullMode) return false
            resize(true)
            return true
        }

        override fun tappedGrabber() {
            haptic(context, "tick")
            resize(!fullMode)
        }

        private fun buildRows() {
            rows.removeAllViews()
            rowViews.clear()
            for (i in sets.indices) {
                val root = android.widget.LinearLayout(context)
                root.gravity = android.view.Gravity.CENTER_VERTICAL
                val n = label(context, 15f, ink(), true)
                n.gravity = android.view.Gravity.CENTER
                val kg = Dial(context, "kg", 1.0, 0.5, 0.0, 400.0)
                val reps = Dial(context, "reps", 1.0, 1.0, 0.0, 60.0)
                val tick = Tick(context)
                kg.onChange = { v ->
                    if (i in sets.indices) {
                        sets[i].kg = v
                        channel?.invokeMethod("setValue", mapOf("i" to i, "kg" to sets[i].kg, "reps" to sets[i].reps))
                    }
                }
                reps.onChange = { v ->
                    if (i in sets.indices) {
                        sets[i].reps = v.toInt()
                        channel?.invokeMethod("setValue", mapOf("i" to i, "kg" to sets[i].kg, "reps" to sets[i].reps))
                    }
                }
                tick.setOnClickListener {
                    channel?.invokeMethod("toggle", i)
                }
                root.addView(n, android.widget.LinearLayout.LayoutParams(px(30f), wrap))
                root.addView(kg, android.widget.LinearLayout.LayoutParams(0, px(56f), 1.12f))
                val repsLp = android.widget.LinearLayout.LayoutParams(0, px(56f), 1f)
                repsLp.leftMargin = px(8f)
                root.addView(reps, repsLp)
                val tickLp = android.widget.LinearLayout.LayoutParams(px(52f), px(56f))
                tickLp.leftMargin = px(4f)
                root.addView(tick, tickLp)
                val lp = android.widget.LinearLayout.LayoutParams(fill, wrap)
                lp.topMargin = px(6f)
                rows.addView(root, lp)
                rowViews.add(Row(root, n, kg, reps, tick))
            }
        }

        /** Lays the same parts out for the small sheet or the tall one. */
        private fun applyMode() {
            val full = fullMode
            // Up while there is a taller sheet to pull out; down once it is out.
            grab.up = !full
            header.orientation = if (full) android.widget.LinearLayout.VERTICAL else android.widget.LinearLayout.HORIZONTAL
            header.gravity = if (full) android.view.Gravity.CENTER_HORIZONTAL else android.view.Gravity.CENTER_VERTICAL
            val size = px(if (full) 150f else 62f)
            clock.layoutParams = android.widget.LinearLayout.LayoutParams(size, size)
            val infoLp = if (full) android.widget.LinearLayout.LayoutParams(wrap, wrap) else android.widget.LinearLayout.LayoutParams(0, wrap, 1f)
            if (full) infoLp.topMargin = px(10f) else infoLp.leftMargin = px(12f)
            info.layoutParams = infoLp
            info.gravity = if (full) android.view.Gravity.CENTER_HORIZONTAL else android.view.Gravity.START
            // Centred under the big timer in the tall sheet; beside the small one otherwise.
            val side = if (full) android.view.Gravity.CENTER_HORIZONTAL else android.view.Gravity.START
            what.gravity = side
            name.gravity = side
            which.gravity = side
            val ctlLp = android.widget.LinearLayout.LayoutParams(wrap, wrap)
            if (full) ctlLp.topMargin = px(12f)
            controls.layoutParams = ctlLp
            // The tall sheet lists every set. The small one shows one, so it says which: the line
            // under the name is written to be read, and the bar below shows it out of how many.
            pips.visibility = if (full) android.view.View.GONE else android.view.View.VISIBLE
            which.setTextColor(if (full) muted() else ink())
            which.textSize = if (full) 12.5f else 14.5f
            which.typeface = android.graphics.Typeface.create(
                if (full) "sans-serif" else "sans-serif-medium",
                if (full) android.graphics.Typeface.NORMAL else android.graphics.Typeface.BOLD,
            )
            sync()
        }

        private fun texts() {
            // A sheet on its way out stays as it was when it was let go.
            if (closing) return
            val t = reading(System.currentTimeMillis())
            // The tall sheet has room to say what a tap does; the small one shows a pair of arrows.
            what.text = when {
                !t.resting -> t.what
                fullMode -> t.what + (if (countUp) "  ·  TAP TO COUNT DOWN" else "  ·  TAP TO COUNT UP")
                else -> t.what + "  ⇄"
            }
            what.setTextColor(if (t.resting) accent else muted())
            val show = if (fullMode && t.resting) android.view.View.VISIBLE else android.view.View.GONE
            if (add.visibility != show) {
                val flip = {
                    add.visibility = show
                    skip.visibility = show
                }
                if (fullMode && !changing && isLaidOut) {
                    // The tall sheet gains or loses a line. The timer keeps its place under the top
                    // edge as that moves, and the two buttons come up once there is room for them.
                    morph(260, emptyList(), listOf(clock, info), null, flip)
                    if (show == android.view.View.VISIBLE) {
                        for (v in listOf(add, skip)) {
                            v.alpha = 0f
                            v.animate().alpha(1f).setStartDelay(110).setDuration(180).start()
                        }
                    }
                } else {
                    flip()
                }
            }
        }

        override fun sync() {
            // A sheet on its way out stays as it was when it was let go.
            if (closing) return
            if (rowViews.size != sets.size) buildRows()
            val full = fullMode
            pips.invalidate()
            name.text = title
            which.text = if (full) exercise else setLabel
            for (i in rowViews.indices) {
                val r = rowViews[i]
                val s = sets[i]
                if (!r.kg.dragging) r.kg.value = s.kg
                if (!r.reps.dragging) r.reps.value = s.reps.toDouble()
                r.tick.done = s.done
                r.kg.isEnabled = !s.done
                r.reps.isEnabled = !s.done
                r.kg.alpha = if (s.done) 0.5f else 1f
                r.reps.alpha = if (s.done) 0.5f else 1f
                r.name.text = if (i == 0) "W" else i.toString()
                r.name.setTextColor(if (i == 0) muted() else ink())
                r.root.visibility = if (full || i == current) android.view.View.VISIBLE else android.view.View.GONE
                r.name.visibility = if (full) android.view.View.VISIBLE else android.view.View.GONE
                r.tick.visibility = if (full) android.view.View.VISIBLE else android.view.View.GONE
                if (full) {
                    r.root.setPadding(px(6f), px(6f), px(4f), px(6f))
                    r.root.background = when {
                        s.done -> rounded(tint(GREEN, 0x1F), 24 * dp)
                        i == current -> rounded(tint(ink(), 0x12), 24 * dp, tint(accent, 0x99), px(1.5f))
                        else -> rounded(tint(ink(), 0x0A), 24 * dp)
                    }
                } else {
                    r.root.setPadding(0, 0, 0, 0)
                    r.root.background = null
                }
            }
            // What it does, and exactly what it will log.
            done.text = if (current in sets.indices) "Set done  \u00B7  " + number(sets[current].kg) + " kg \u00D7 " + sets[current].reps else "Set done"
            // On Prism's own workout page there is nowhere for this to take you.
            open.visibility = if (RestBubble.foreground && onTrain) android.view.View.GONE else android.view.View.VISIBLE
            done.setTextColor(onAccent)
            done.background = rounded(accent, 100 * dp)
            texts()
            clock.invalidate()
        }
    }

    /**
     * The sheet of a pinned action: the thing itself, done in place, over whatever app is open.
     * Nothing in it runs until it is opened, and nothing is left running when it closes.
     */
    private class ActionSheet(context: Context, val index: Int) : Sheet(context) {
        private val title = label(context, 19f, ink(), true)
        private val sub = label(context, 12.5f, muted(), false)
        private val save = label(context, 16.5f, onAccent, true)
        private var dial: Dial? = null

        init {
            val head = android.widget.LinearLayout(context)
            head.gravity = android.view.Gravity.CENTER_VERTICAL
            val names = android.widget.LinearLayout(context)
            names.orientation = android.widget.LinearLayout.VERTICAL
            names.addView(title)
            names.addView(sub, android.widget.LinearLayout.LayoutParams(wrap, wrap).also { it.topMargin = px(3f) })
            head.addView(names, android.widget.LinearLayout.LayoutParams(0, wrap, 1f))
            val open = label(context, 13f, ink(), true)
            // Only where it leads somewhere: inside Prism, the same thing is already at hand.
            open.visibility = if (RestBubble.foreground) android.view.View.GONE else android.view.View.VISIBLE
            open.text = "Open in Prism"
            open.setPadding(px(14f), px(10f), px(14f), px(10f))
            open.background = rounded(tint(ink(), 0x1F), 100 * dp)
            open.setOnClickListener {
                haptic(context, "tick")
                openAction(context, index)
            }
            head.addView(open)
            card.addView(head, android.widget.LinearLayout.LayoutParams(fill, wrap))

            if (index == 3) {
                // Weigh-in: one wide dial in tenths of a kilo, and a button that says what it will save.
                title.text = "Weigh-in"
                val d = Dial(context, "kg", 0.1, 0.1, 20.0, 300.0)
                d.value = Math.round(weight * 10) / 10.0
                d.onChange = { v -> save.text = "Save " + number(v) + " kg" }
                dial = d
                card.addView(d, android.widget.LinearLayout.LayoutParams(fill, px(72f)).also { it.topMargin = px(14f) })
                save.gravity = android.view.Gravity.CENTER
                save.background = rounded(accent, 100 * dp)
                save.setOnClickListener {
                    // Prism saves it and gives the click.
                    channel?.invokeMethod("weigh", d.value)
                    closeSheet(context)
                }
                card.addView(save, android.widget.LinearLayout.LayoutParams(fill, px(56f)).also { it.topMargin = px(12f) })
            } else {
                // Log food: the usual meals, one tap each.
                title.text = "Log food"
                for (m in meals) {
                    val row = android.widget.LinearLayout(context)
                    row.gravity = android.view.Gravity.CENTER_VERTICAL
                    row.background = rounded(tint(ink(), 0x10), 22 * dp)
                    row.setPadding(px(16f), px(9f), px(8f), px(9f))
                    val col = android.widget.LinearLayout(context)
                    col.orientation = android.widget.LinearLayout.VERTICAL
                    val n = label(context, 15.5f, ink(), true)
                    n.text = m.name
                    val w = label(context, 12.5f, muted(), false)
                    w.text = m.what
                    col.addView(n)
                    col.addView(w, android.widget.LinearLayout.LayoutParams(wrap, wrap).also { it.topMargin = px(2f) })
                    row.addView(col, android.widget.LinearLayout.LayoutParams(0, wrap, 1f))
                    val k = label(context, 14f, ink(), true)
                    k.text = m.kcal.toString() + " kcal"
                    row.addView(k, android.widget.LinearLayout.LayoutParams(wrap, wrap).also { it.rightMargin = px(10f) })
                    val plus = label(context, 22f, onAccent, true)
                    plus.text = "+"
                    plus.gravity = android.view.Gravity.CENTER
                    plus.background = rounded(accent, 100 * dp)
                    plus.setOnClickListener {
                        // Prism adds it and gives the click.
                        channel?.invokeMethod("food", m.index)
                    }
                    row.addView(plus, android.widget.LinearLayout.LayoutParams(px(46f), px(46f)))
                    card.addView(row, android.widget.LinearLayout.LayoutParams(fill, wrap).also { it.topMargin = px(8f) })
                }
            }
            sync()
        }

        override fun pulledDown() {
            closeSheet(context)
        }

        override fun sync() {
            val d = dial
            if (d != null) {
                sub.text = "Now " + number(weight) + " kg"
                save.setTextColor(onAccent)
                save.text = "Save " + number(d.value) + " kg"
            } else {
                sub.text = if (kcalLeft >= 0) kcalLeft.toString() + " kcal left today" else (-kcalLeft).toString() + " kcal over today"
            }
        }
    }
}
